# React Movies

Install libraries `npm i`

Start Project `npm start`

